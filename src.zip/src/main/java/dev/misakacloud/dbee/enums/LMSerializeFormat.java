package dev.misakacloud.dbee.enums;

public interface LMSerializeFormat {
    byte getId();

    String getDescription();

    int getEncryptedLength();
}

