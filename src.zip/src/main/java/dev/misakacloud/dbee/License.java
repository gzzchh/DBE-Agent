package dev.misakacloud.dbee;

import dev.misakacloud.dbee.enums.LMLicenseFormat;
import dev.misakacloud.dbee.enums.LMLicenseType;
import dev.misakacloud.dbee.enums.LMStatusDetails;
import dev.misakacloud.dbee.utils.Convert;
import dev.misakacloud.dbee.utils.Crypt;

import java.security.Key;
import java.util.Date;

public class License {
    private byte[] encoded;
    private String licenseId;
    private dev.misakacloud.dbee.enums.LMLicenseType licenseType;
    private Date licenseIssueTime;
    private Date licenseStartTime;
    private Date licenseEndTime;
    private long flags;
    private String productId;
    private String productVersion;
    private String ownerId;
    private String ownerCompany;
    private String ownerName;
    private String ownerEmail;
    private byte yearsNumber;
    private byte reserved1;
    private short usersNumber;
    private LMLicenseFormat licenseFormat;
    private LMStatusDetails remoteStatus;
    private int offset = 0;



    public License (byte[] encryptedData, Key key) throws Exception {
        this.encoded = encryptedData;
        String encryptedDataStr = new String(encryptedData);
        byte[] data = Crypt.decryptLicense(encryptedDataStr, key);
        int offset = 0;
        this.licenseFormat = LMLicenseFormat.STANDARD;

        try {
            this.licenseFormat = LMLicenseFormat.valueOf(data[offset]);
        } catch (Exception var5) {
//            log.warning("Unsupported license format: " + data[offset]);
        }

        offset = offset + 1;
        if (data.length != this.licenseFormat.getEncryptedLength()) {
            throw new Exception("Bad " + this.licenseFormat + " license length (" + data.length + ")");
        } else {
            this.licenseId = (new String(data, offset, 16)).trim();
            offset += 16;
            this.licenseType = LMLicenseType.valueOf(data[offset]);
            ++offset;
            this.licenseIssueTime = Convert.getDateFromBytes(data, offset);
            offset += 8;
            this.licenseStartTime = Convert.getDateFromBytes(data, offset);
            offset += 8;
            this.licenseEndTime = Convert.getDateFromBytes(data, offset);
            offset += 8;
            this.flags = Convert.bytesToLong(data, offset);
            offset += 8;
            this.productId = (new String(data, offset, 16)).trim();
            offset += 16;
            this.productVersion = (new String(data, offset, 8)).trim();
            offset += 8;
            this.ownerId = (new String(data, offset, 16)).trim();
            offset += 16;
            this.ownerCompany = (new String(data, offset, 64)).trim();
            offset += 64;
            if (this.licenseFormat == LMLicenseFormat.STANDARD) {
                this.ownerName = (new String(data, offset, 64)).trim();
                offset += 64;
            } else {
                this.ownerName = (new String(data, offset, 32)).trim();
                offset += 32;
                this.ownerEmail = (new String(data, offset, 48)).trim();
                offset += 48;
                this.yearsNumber = data[offset++];
                if (this.yearsNumber <= 0) {
                    this.yearsNumber = 1;
                }

                this.reserved1 = data[offset++];
                this.usersNumber = Convert.bytesToShort(data, offset);
                if (this.usersNumber <= 0) {
                    this.usersNumber = 1;
                }

                offset += 2;
            }

        }
    }

    public License(String licenseId, LMLicenseType licenseType, Date licenseIssueTime, Date licenseStartTime, Date licenseEndTime, long flags, String productId, String productVersion, String ownerId, String ownerCompany, String ownerName, String ownerEmail) {
        this.licenseFormat = LMLicenseFormat.EXTENDED;
        this.licenseId = licenseId;
        this.licenseType = licenseType;
        this.licenseIssueTime = licenseIssueTime;
        this.licenseStartTime = licenseStartTime;
        this.licenseEndTime = licenseEndTime;
        this.flags = flags;
        this.productId = productId;
        this.productVersion = productVersion;
        this.ownerId = ownerId;
        this.ownerCompany = ownerCompany;
        this.ownerName = ownerName;
        this.ownerEmail = ownerEmail;
        this.yearsNumber = 1;
        this.reserved1 = 0;
        this.usersNumber = 1;
    }

    public String toString() {
        return "licenseId=" + this.licenseId + "\nlicenseType=" + this.licenseType + "\nlicenseIssueTime=" + this.licenseIssueTime + "\nlicenseStartTime=" + this.licenseStartTime + "\nlicenseEndTime=" + this.licenseEndTime + "\nflags=" + this.flags + "\nproductId=" + this.productId + "\nproductVersion=" + this.productVersion + "\nownerId=" + this.ownerId + "\nownerCompany=" + this.ownerCompany + "\nownerName=" + this.ownerName + "\nownerEmail=" + this.ownerEmail + "\nyearsNumber=" + this.yearsNumber + "\nusersNumber=" + this.usersNumber;
    }
}
